<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Http\Resources\userResource;
use App\Models\users;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
class user extends Controller
{
   

    public function regester(Request $request)
    {


    


        $regestersuccess='';
        $emailexets='';
        $users = users::where('email', $request->email)->get();

        # check if email is more than 1

        if(sizeof($users) > 0){
            # tell user not to duplicate same email
            $emailexets=true;
            return response()->json(['message' => trans('response.failed'),compact('emailexets')], 444);
            
        }


        // $randomString =Str::upper(Str::random(16));

        // $check_token_ = user_vts::where('email', $randomString)->get();

        // if(sizeof($check_token_) != 0){
            
        //     $randomString =Str::upper(Str::random(16));

            
        // }

       
   

        // $request->validate([
        //     'name' => 'required',
        //     'email' => 'required|unique:users|string|email|max:255',
        //     'phone' => 'required',
        //     'password' => 'required',
        //     // 'pakeg_tyep' => 'required',
        //     // 'Payment_status' => 'required',
        //     // 'pakeg_name' => 'required',
      

     
        // ]);


        $data= users::create(
            [
                 'name' => $request->name,
                 'email' => $request->email,
                 'phone' => $request->phone,
                 'password' =>Hash::make( $request->password ),
                 'stat' => $request->stat,
                 'city' => $request->city,
                //  'ather_inform' => $request->ather_inform,
                 
                
             ]);



        if (!$data->save()) {
            $regestersuccess=false;
            return response()->json(['message' => trans('regester.failed'),compact('regestersuccess')], 444);

        }



        $data->save();
        $regestersuccess=true;

        
        return response()->json(['data' => 
        userResource::collection(users::where('email', '=', $request->email,)->get()) 
        ,compact('regestersuccess')], 200);






    }











    public function login(Request $request)
    {



     


                $loginsuccess='';
                $request->validate([

                    'email' => 'required',
                    'password' => 'required',
                ]);

                $userinfo = users::where('email', '=', $request->email)->first();

                if (!$userinfo) {

                            return response()->json(['message' => trans('nooo')], 404);
                }else{

                    if (Hash::check($request->password, $userinfo->password)) {
       

                        $loginsuccess=true;
                        return response()->json(['data' => 
                        userResource::collection(users::where('email', '=', $request->email,)->get()) 
                        ,compact('loginsuccess')], 200);

                    } else {
                        $loginsuccess=false;

                        return response()->json(['message' => trans('411111') , compact('loginsuccess')], 404);
                    }
                
                }


 


    }


}


